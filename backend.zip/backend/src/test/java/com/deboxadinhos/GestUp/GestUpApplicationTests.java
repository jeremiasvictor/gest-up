package com.deboxadinhos.GestUp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GestUpApplicationTests {

	@Test
	void contextLoads() {
	}

}
