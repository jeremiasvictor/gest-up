package com.deboxadinhos.GestUp;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController // indica que retorna json
@RequestMapping("/produtos") //cria a rota produtos
public class produtoController {

    @Autowired //diz ao Spring para injetar automaticamente uma instância do ProdutoRepository.
    private ProdutoRepository produtoRepository;

    @GetMapping
    public List<Produto> listar(){
        return produtoRepository.findAll();
    }

    @GetMapping("/{id}") //cria a rota so para id
    public Produto buscarPorid(@PathVariable long id){

        for (Produto produto : produtoRepository.findAll()){
            if(produto.getId() == id){
                return produto;
            }
        }

        return null; // nao achou
    }

    @PostMapping //
    public Produto salvar(@RequestBody Produto produto){
        return produtoRepository.save(produto);
    }


}
