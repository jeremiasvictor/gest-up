package com.deboxadinhos.GestUp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GestUpApplication {
	public static void main(String[] args) {
		SpringApplication.run(GestUpApplication.class, args);
	}

}
